//
//  ConferenceCell.swift
//  CocoaHeadsSwift
//
//  Created by Guilherme Endres on 11/5/15.
//  Copyright © 2015 ArcTouch. All rights reserved.
//

import UIKit

class ConferenceCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
}